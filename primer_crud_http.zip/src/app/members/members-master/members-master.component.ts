import { Component, OnInit } from '@angular/core';
import { MembersService } from '../services/members.service';

// Declaramos las variables para jQuery
declare var jQuery: any;
declare var $: any;

@Component({
  selector: 'api-members-master',
  templateUrl: './members-master.component.html',
  styleUrls: ['./members-master.component.css']
})
export class MembersMasterComponent implements OnInit {

  constructor(public membersService: MembersService) { }

  ngOnInit() {
    $(document).prop('title', 'Socios');
    $('.menuLink').removeClass('active');
    $('#MembersMenuLink').addClass('active');
  }

}
