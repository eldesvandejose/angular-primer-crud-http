import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MembersMasterComponent } from './members-master.component';

describe('MembersMasterComponent', () => {
  let component: MembersMasterComponent;
  let fixture: ComponentFixture<MembersMasterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MembersMasterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MembersMasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
