import { Component, OnInit } from '@angular/core';
import { MembersService } from '../services/members.service';

@Component({
  selector: 'api-members-form',
  templateUrl: './members-form.component.html',
  styleUrls: ['./members-form.component.css']
})
export class MembersFormComponent implements OnInit {

  constructor(public membersService: MembersService) { }

  ngOnInit() { }

}
