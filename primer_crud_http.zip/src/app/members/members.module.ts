import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { MembersMasterComponent } from './members-master/members-master.component';
import { MembersFormComponent } from './members-form/members-form.component';
import { MembersListComponent } from './members-list/members-list.component';
import { MembersService } from './services/members.service';

@NgModule({
  imports: [
    CommonModule,
    FormsModule
  ],
  declarations: [
    MembersMasterComponent,
    MembersFormComponent,
    MembersListComponent
  ],
  providers: [
    MembersService
  ]
})
export class MembersModule { }
