import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { HttpClient } from '@angular/common/http';

import { Member } from '../classes/member';
import { environment } from '../../../environments/environment';

@Injectable()
export class MembersService {
  /**
   * DECLARACIÓN DE LAS VARIABLES QUE SE EMPLEARÁN EN EL MÓDULO
   */

  private URL = environment.API_URL;

  private User: Member; // Almacenará los datos de un nuevo usuario en un objeto de la clase adecuada
  public UsersArray: Member[] = []; // Almacenará los objetos de clase Member en una matriz
  public NumberOfMembers = 0; // Contendrá el número de miembros cuando se añadan o eliminen

  public typeOfAction = 'C'; // (C)rear o (E)ditar

  public dni: string; // Para el ngModel con el formulario
  public nombre: string; // Para el ngModel con el formulario

  public emptyFields = false; // Para el mensaje cuando falten datos al intentar grabar
  public repeatedDNI = false; // Para el mensaje cuando se intenté grabar un DNI repretido
  public dataUpgradedOk = false; // Para el mensaje cuando se graben correctamente los datos de un nuevo miembro
  public executionError = false; // Para indicar si se han producido errores de ejecución.

  constructor(private http: HttpClient) {
    // Se inicializan en blanco las variables del ngModel del formulario
    this.dni = '';
    this.nombre = '';
    this.readRecords();
  }

  /* Métodos para comunicación con el servidor.
  No son invocados directamente, si no a través de
  métodos invocadores.
  No devuelven los datos directamente, si no que
  devuelven una envolvente Observable, que debe ser
  suscrita por los métodos invocadores */
  private saveRecord$(member: Member): Observable<any> {
    return this.http.post(this.URL + 'save_record.php', member);
  }

  private readRecords$(): Observable<Member[]> {
    return this.http.get<Member[]>(this.URL + 'read_records.php');
  }

  private editRecord$(member: Member): Observable<any> {
    return this.http.post(this.URL + 'edit_record.php', member);
  }

  private deleteRecord$(id: string): Observable<any> {
    return this.http.post(this.URL + 'delete_record.php', id);
  }

  /**
   * El siguiente método comprueba los datos tecleados en el formulario cuando se intenta grabar.
   * El método que se invoca a continuación difiere si es un alta nueva, o una edición.
   */
  public checkRecord() {
    if (this.dni === '' || this.nombre === '') {
      this.emptyFields = true;
    }
    if (!this.emptyFields === true) {
      if (this.typeOfAction === 'C') {
        this.User = new Member(this.dni, this.nombre);
        this.saveRecord();
      } else {
        this.editRecord();
      }
    }
  }

  /**
   * GRABACIÓN DE UN NUEVO REGISTRO
   */
  private saveRecord() {
    this.saveRecord$(this.User).subscribe(
      this.saveSuccess.bind(this),
      this.catchError.bind(this)
    );
  }
  // Grabado con éxito, o no se pudo grabar por estar duplicado el DNI.
  private saveSuccess(result) {
    if (result === '23000') {
      this.repeatedDNI = true;
    } else {
      this.dataUpgradedOk = true;
      this.dni = '';
      this.nombre = '';
    }
    this.readRecords();
  }

  /* EDICIÓN DE UN REGISTRO */
  public showDataToEdit(record: Member) {
    this.User = record;
    this.dni = record.dni;
    this.nombre = record.nombre;
    this.typeOfAction = 'E';
  }

  private editRecord() {
    this.User.dni = this.dni;
    this.User.nombre = this.nombre;
    this.editRecord$(this.User).subscribe(
      this.saveSuccess.bind(this),
      this.catchError.bind(this)
    );
  }

  /* BORRADO DE UN REGISTRO */
  public deleteRecord(id: string) {
    this.deleteRecord$(id).subscribe(
      this.deleteSuccess.bind(this),
      this.catchError.bind(this)
    );
  }
  // Borrado correctamente
  private deleteSuccess(result) {
    if (result === 'KO') {
      this.executionError = true;
    } else {
      this.dataUpgradedOk = true;
      this.readRecords();
    }
  }

  /* LECTURA DE LISTA DE REGISTROS */
  private readRecords() {
    this.readRecords$().subscribe(
      this.readSuccess.bind(this),
      this.catchError.bind(this)
    );
  }
  // Leidos correctamente
  private readSuccess(membersList) {
    this.UsersArray = membersList;
    this.NumberOfMembers = this.UsersArray.length;
  }

  // Si el proceso de grabación ha dado algún error de ejecución.
  // Este método es común a la grabación, edición, listado y borrado.
  private catchError() {
    this.dataUpgradedOk = false;
    this.repeatedDNI = false;
    this.emptyFields = false;
    this.executionError = true;
  }

  /**
   * Cuando se enfoca un campo del formulario se borra la última notificación
   */
  public clearNotice() {
    this.executionError = false;
    this.emptyFields = false;
    this.repeatedDNI = false;
    this.dataUpgradedOk = false;
  }

  public cancelEdition() {
    this.typeOfAction = 'C';
    this.dni = '';
    this.nombre = '';
  }
}
